<?php
$con=new mysqli('localhost','root','','crudoperation');

if($con){
    echo "connection successfull"."<br>";
}else{
    die(mysqli_error());
}
?>