<?php
include 'connect.php';
$id=$_GET['updateid'];
$sql="select * from crud where id=$id";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($result);
$name=$row['name'];
$email=$row['email'];
$phoneno=$row['mobile'];
$password=$row['password'];

if(isset($_POST['submit'])){
  $name=$_POST['name'];
  $email=$_POST['email'];
  $phoneno=$_POST['mobile'];
  $password=$_POST['password'];
  
$sql="update crud set name='$name',email='$email',mobile='$phoneno',password='$password' where id=$id";
$result=mysqli_query($con,$sql);
  if($result){
    // echo "update successfully";
    header ("location:display.php");
  }else{
    die(mysqli_error($con));
  }
}

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>hello</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  </head>
  <body>
    <div class="container my-4">
    <form method="post">
  <div class="form-group">
    <label>name</label>
    <input type="text" class="form-control" 
    placeholder="enter your name"
    name="name" autocomplete="off" value=<?php echo $name;?>></div>
    <div class="form group">
    <label>email</label>
    <input type="email" class="form-control" 
    placeholder="enter your email"
    name="email" autocomplete="off" value=<?php echo $email;?>></div>
    <div class="form-group">
    <label>phoneno</label>
    <input type="text" class="form-control" 
    placeholder="enter your mobile"
    name="mobile" autocomplete="off" value=<?php echo $phoneno;?>></div>
    <div class="form-group">
    <label>password</label>
    <input type="text" class="form-control" 
    placeholder="enter your password"
    name="password" autocomplete="off" value=<?php echo $password;?>></div>
  
    </div>
    <button type="submit" class="btn btn-primary" name="submit">update</button>
</form>
</body>

</html>